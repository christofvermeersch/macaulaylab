function r = recrrank()
    %RECRRANK   Recursive rank computation.

    error("Not yet implemented.")
end
